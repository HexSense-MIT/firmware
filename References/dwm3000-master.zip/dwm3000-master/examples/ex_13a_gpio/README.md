# DWM3000 - ex_13a_gpio

## Overview

## Requirements

## Building and Running

## Sample Output
```
*** Booting Zephyr OS build zephyr-v2.5.0-1675-gd6567ad494a0  ***

[00:00:03.857,696] <inf> main: main_thread
[00:00:03.857,696] <inf> port: Configure WAKEUP pin
[00:00:03.857,727] <inf> port: Configure RESET pin
[00:00:03.857,727] <inf> port: Configure RX LED pin
[00:00:03.857,727] <inf> port: Configure TX LED pin
[00:00:03.857,727] <inf> deca_spi: openspi bus SPI_3
[00:00:04.885,559] <inf> ack_data_rx: GPIO v1.0
[00:00:04.885,589] <inf> port: reset_DWIC
[00:00:04.890,197] <inf> deca_device: dev_id "deca0302"
```
Both red and green LED will be blinking.
