# DWM3000 - ex_04a_continuous_wave

## Overview

## Requirements

## Building and Running

## Sample Output
```
*** Booting Zephyr OS build zephyr-v2.5.0-1675-gd6567ad494a0  ***

[00:00:04.327,178] <inf> main: main_thread
[00:00:04.327,178] <inf> port: Configure WAKEUP pin
[00:00:04.327,209] <inf> port: Configure RESET pin
[00:00:04.327,209] <inf> port: Configure RX LED pin
[00:00:04.327,209] <inf> port: Configure TX LED pin
[00:00:04.327,209] <inf> deca_spi: openspi bus SPI_3
[00:00:05.354,980] <inf> cont_wave: CONT WAVE v1.0
[00:00:05.355,041] <inf> port: reset_DWIC
[00:00:05.359,649] <inf> deca_device: dev_id "deca0302"
[00:00:05.362,518] <inf> cont_wave: Continuous wave output for 120000ms
[00:02:05.365,417] <inf> cont_wave: done
```

No LED indications
