
cmake -B build .
