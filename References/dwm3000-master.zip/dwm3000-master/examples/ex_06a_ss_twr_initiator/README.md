# DwM3000 - ex_06a_ss_twr_initiator

## Overview

## Requirements

## Building and Running

## Sample Output
```
*** Booting Zephyr OS build zephyr-v2.5.0-1675-gd6567ad494a0  ***

[00:00:02.596,954] <inf> main: main_thread
[00:00:02.596,954] <inf> port: Configure WAKEUP pin
[00:00:02.596,984] <inf> port: Configure RESET pin
[00:00:02.596,984] <inf> port: Configure RX LED pin
[00:00:02.596,984] <inf> port: Configure TX LED pin
[00:00:02.597,015] <inf> deca_spi: openspi bus SPI_3
[00:00:03.624,908] <inf> ss_twr_init: SS TWR INIT v1.0
[00:00:03.624,938] <inf> port: reset_DWIC
[00:00:03.629,638] <inf> deca_device: dev_id "deca0302"
[00:00:03.633,270] <inf> ss_twr_init: Initiator ready
[00:00:03.634,674] <inf> ss_twr_init: dist 1.03 m
[00:00:04.649,993] <inf> ss_twr_init: dist 0.90 m
[00:00:05.656,066] <inf> ss_twr_init: dist 1.00 m
[00:00:06.662,170] <inf> ss_twr_init: dist 1.01 m
[00:00:07.668,243] <inf> ss_twr_init: dist 1.08 m
[00:00:08.674,316] <inf> ss_twr_init: dist 1.23 m
[00:00:10.681,579] <inf> ss_twr_init: dist 0.99 m
[00:00:11.687,683] <inf> ss_twr_init: dist 0.96 m
[00:00:12.693,786] <inf> ss_twr_init: dist 1.44 m
[00:00:13.699,890] <inf> ss_twr_init: dist 1.93 m
[00:00:14.705,993] <inf> ss_twr_init: dist 1.93 m
```
