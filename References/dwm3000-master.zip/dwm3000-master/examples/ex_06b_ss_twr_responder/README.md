# DWM3000 - ex_06b_ss_twr_responder

## Overview

## Requirements

## Building and Running

## Sample Output
```
*** Booting Zephyr OS build zephyr-v2.5.0-1675-gd6567ad494a0  ***

[00:00:03.512,268] <inf> main: main_thread
[00:00:03.512,298] <inf> port: Configure WAKEUP pin
[00:00:03.512,298] <inf> port: Configure RESET pin
[00:00:03.512,298] <inf> port: Configure RX LED pin
[00:00:03.512,298] <inf> port: Configure TX LED pin
[00:00:03.512,329] <inf> deca_spi: openspi bus SPI_3
[00:00:04.540,496] <inf> ss_twr_resp: SS TWR RESP v1.0
[00:00:04.540,527] <inf> port: reset_DWIC
[00:00:04.545,227] <inf> deca_device: dev_id "deca0302"
```
