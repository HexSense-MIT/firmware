# DWM3000 - ex_02c_rx_diagnostics

## Overview

## Requirements

## Building and Running

## Sample Output
```
*** Booting Zephyr OS build zephyr-v2.5.0-1675-gd6567ad494a0  ***

[00:00:04.570,098] <inf> main: main_thread
[00:00:04.570,129] <inf> port: Configure WAKEUP pin
[00:00:04.570,129] <inf> port: Configure RESET pin
[00:00:04.570,129] <inf> port: Configure RX LED pin
[00:00:04.570,159] <inf> port: Configure TX LED pin
[00:00:04.570,159] <inf> deca_spi: openspi bus SPI_3
[00:00:05.597,961] <inf> rx_diagnostics: RX DIAG v1.0
[00:00:05.598,022] <inf> port: reset_DWIC
[00:00:05.602,630] <inf> deca_device: dev_id "deca0302"
[00:00:05.605,651] <inf> rx_diagnostics: Diagnostics ready
```
Currently there is no real useful diagnostic data logged. `<REVIEW>`
  
